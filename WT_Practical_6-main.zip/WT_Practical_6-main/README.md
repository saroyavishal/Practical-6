# HW4: Music Box

This is the starter code for HW4: Music Box. Please [check out the spec](https://web.stanford.edu/class/archive/cs/cs193x/cs193x.1176/homework/4-musicbox) for an explanation of the starter files.
